<template>
  <div>
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'AuthLayout',
}
</script>
