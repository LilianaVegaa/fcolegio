export default class Curso {
  constructor(nombre = '', descripcion = '') {
      this.nombre = nombre;
      this.descripcion = descripcion;
  }
}
