export default class Gestion {
  constructor(año = '', fecha_inicio = '', fecha_fin = '') {
      this.año = año;
      this.fecha_inicio = fecha_inicio;
      this.fecha_fin = fecha_fin;
  }
}
