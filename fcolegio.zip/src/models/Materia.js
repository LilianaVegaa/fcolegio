export default class Materia {
  constructor(nombre = '', descripcion = '') {
    this.nombre = nombre;
    this.descripcion = descripcion;
}
}
