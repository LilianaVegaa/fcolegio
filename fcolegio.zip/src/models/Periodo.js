export default class Periodo {
  constructor(nombre = '', pruebas = null, gestion_id = null) {
      this.nombre = nombre;
      this.pruebas = pruebas;
      this.gestion_id = gestion_id;
  }
}
