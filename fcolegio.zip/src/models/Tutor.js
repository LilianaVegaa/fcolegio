export default class Tutor {
  constructor(nombres = '', apellidos = '', telefono = '', direccion='', ci = '') {
      this.nombres = nombres;
      this.apellidos = apellidos;
      this.telefono = telefono;
      this.direccion = direccion;
      this.ci = ci;
  }
}
