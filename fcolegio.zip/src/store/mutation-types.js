// feedback.js
export const RESPONSE_MSG = 'RESPONSE_MSG'
export const CLEAR_MSG = 'CLEAR_MSG'