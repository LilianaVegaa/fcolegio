<template>
  <div class="bg-light">
    <error-403 />
  </div>
</template>
<script>
import Error403 from '@/components/system/Errors/403'
export default {
  components: {
    Error403,
  },
}
</script>
