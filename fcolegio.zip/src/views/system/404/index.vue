<template>
  <div class="bg-light">
    <error-404 />
  </div>
</template>
<script>
import Error404 from '@/components/system/Errors/404'
export default {
  components: {
    Error404,
  },
}
</script>
